from mmpy_bot import Plugin
from mmpy_bot.scheduler import schedule
from loguru import logger
from malware_database import db
from mmpy_bot.function import listen_to
import subprocess

class AdminPlugin(Plugin):
    """
    A plugin to handle administration utilities
    """

    @listen_to("^!util df", allowed_users_glob=["mod_*","admin_*"])
    def df_cmd(self, message ):
        logger.info(f"AdminPlugin: running df")
        result = subprocess.run(["df", "-h", "-x", "tmpfs"],capture_output=True, text=True)
        self.driver.reply_to(message, f"{result.stdout}")

    @listen_to("^!util uptime$", allowed_users_glob=["mod_*","admin_*"])
    def uptime_cmd(self, message):
        logger.info("AdminPlugin: running uptime")
        result = subprocess.run(["uptime"], capture_output=True, text=True)
        self.driver.reply_to(message, f"{result.stdout}")

    @listen_to("^!util free$", allowed_users_glob=["mod_*","admin_*"])
    def free_cmd(self, message):
        logger.info("AdminPlugin: running free -h")
        result = subprocess.run(["free", "-h"], capture_output=True, text=True)
        self.driver.reply_to(message, f"{result.stdout}")


    