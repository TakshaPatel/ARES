# mmpy_bot_monkeypatch.py
"""
Monkey patch mmpy_bot MessageFunction to support no_direct option.
"""
from mmpy_bot.function import MessageFunction
from mmpy_bot.utils import completed_future
import fnmatch
from loguru import logger

# Save original methods
_original_init = MessageFunction.__init__
_original_call = MessageFunction.__call__

def patched_init(self, *args, allowed_users_glob=None, **kwargs):
    logger.debug(f"patched_init called for {getattr(self, 'name', None)} with allowed_users_glob={allowed_users_glob} and no_direct={kwargs.get('no_direct', False)}")
    _original_init(self, *args, **kwargs)
    self.no_direct = kwargs.get('no_direct', False)
    # allowed_users_glob setup
    if allowed_users_glob is not None:
        logger.debug(f"Setting allowed_users_glob: {allowed_users_glob}")
        self.allowed_users_glob = [pattern.lower() for pattern in allowed_users_glob]
    elif hasattr(self, 'allowed_users_glob'):
        logger.debug("allowed_users_glob already set")
        pass  # already set
    else:
        self.allowed_users_glob = []
        logger.debug("allowed_users_glob set to empty list")

def patched_call(self, message, *args):
    logger.debug(f"patched_call for {getattr(self, 'name', None)} from sender={message.sender_name}")
    # If no_direct is set and this is a direct message, skip
    if getattr(self, 'no_direct', False) and message.is_direct_message:
        logger.debug("no_direct is set and message is direct, skipping handler")
        return None if not self.is_coroutine else completed_future()
    # Combined exact and glob matching for allowed_users
    sender = message.sender_name.lower()
    allowed_exact = sender in getattr(self, 'allowed_users', [])
    allowed_glob = any(fnmatch.fnmatch(sender, pattern) for pattern in getattr(self, 'allowed_users_glob', []))
    logger.debug(f"allowed_exact={allowed_exact}, allowed_glob={allowed_glob}, allowed_users={getattr(self, 'allowed_users', [])}, allowed_users_glob={getattr(self, 'allowed_users_glob', [])}")
    if getattr(self, 'allowed_users', None) or getattr(self, 'allowed_users_glob', None):
        if not (allowed_exact or allowed_glob):
            logger.debug(f"Permission denied for sender={sender}")
            if not getattr(self, 'silence_fail_msg', False):
                self.plugin.driver.reply_to(
                    message, "You do not have permission to perform this action!"
                )
            return None if not self.is_coroutine else completed_future()
        else:
            logger.debug(f"Permission granted for sender={sender}")
    return _original_call(self, message, *args)

MessageFunction.__init__ = patched_init
MessageFunction.__call__ = patched_call
