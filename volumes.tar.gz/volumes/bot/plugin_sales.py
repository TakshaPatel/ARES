from mmpy_bot_monkeypatch import *  # Ensure monkeypatch is applied before anything else
from mmpy_bot import Plugin, Message, listen_to
from malware_database import db
from loguru import logger

MALWARE_TYPES = ["0click", "1click", "LPE", "SBE", "RCE", "Phishing", "ExploitKit", "Backdoor", "Rootkit"]
OS_TYPES = ["Windows", "Linux", "macOS", "Android", "iOS", "Unix"]
ODAYS = ["0day", "nday"]

class SalesPlugin(Plugin):
    """
    A plugin to handle sales in Mattermost.
    """

    @listen_to('^!nego (.*)$', no_direct=True,human_description="!nego channel seller moderator1 moderator2\n\tCreate a negotiation channel to close a deal!")
    def handle_nego(self : Plugin, message: Message, *args):
        logger.debug(f"handle_nego called with message: {message.text}")
        args = message.text.strip().split()
        if len(args) != 5:
            self.driver.reply_to(message, "Usage: !nego channel seller moderator1 moderator2")
            logger.warning("handle_nego: Incorrect number of arguments")
            return
        user1 = message.sender_name
        _, channel_name, user2, user3, user4 = args[:6]
        if not user4.startswith('mod_'):
            self.driver.reply_to(message, f"You must have a mod")
            return
        display_name = channel_name
        team_name = self.driver.options.get('team', 'malwarecentral')
        print(f"[DEBUG] Looking up team: {team_name}")
        # Get team info
        team = self.driver.teams.get_team_by_name(team_name)
        logger.debug(f"Team API response: {team}")
        team_id = team.get('id') if isinstance(team, dict) else team.json().get('id')
        print(f"[DEBUG] team_id: {team_id}")
        # Create channel
        channel_options = {
            "team_id": team_id,
            "name": channel_name,
            "display_name": display_name,
            "type": "P"
        }
        logger.debug(f"Creating channel with options: {channel_options}")
        try:
            channel = self.driver.channels.create_channel(channel_options)
            print(f"[DEBUG] Channel API response: {channel}")
        #hide weird exception when we have an archived channel with the same name, we'll just unarchive it
        except Exception as e:
            print(f"[DEBUG] Exception while creating channel: {e}")
            # Try to unarchive the channel if it exists
            try:
                archived_channel = self.driver.channels.get_channel_by_name(channel_name, team_id)
                if archived_channel and archived_channel.get('delete_at') > 0:
                    logger.info(f"Unarchiving existing channel: {archived_channel}")
                    self.driver.channels.unarchive_channel(archived_channel.get('id'))
                    channel = archived_channel
            except Exception as e:
                self.driver.reply_to(message, f"Failed to create or unarchive channel: {e}")
        #we either created a new channel or unarchived an existing one
        print(f"[DEBUG] getting channel: {channel_name} in team {team_id}")
        channel = self.driver.channels.get_channel_by_name(team_id, channel_name)
        channel_id = channel.get('id') if isinstance(channel, dict) else channel.json().get('id')
        print(f"[DEBUG] channel_id: {channel_id}")
        # Get user ids
        user_ids = []
        for uname in [user1, user2, user3, user4]:
            logger.debug(f"Looking up user: {uname}")
            user = self.driver.users.get_user_by_username(uname)
            logger.debug(f"User API response: {user}")
            uid = user.get('id') if isinstance(user, dict) else user.json().get('id')
            logger.debug(f"user_id for {uname}: {uid}")
            if not uid:
                self.driver.reply_to(message, f"User not found: {uname}")
                logger.warning(f"handle_nego: User not found: {uname}")
                return
            user_ids.append(uid)
        if len(set(user_ids)) != 4:
            logger.warning(f"incorrect number of users to run command")
            self.driver.reply_to(message, f"incorrect number of users to run command")
            return
        print(f"[DEBUG] All user_ids: {user_ids}")

        # Check if channel already has members
        existing_members = self.driver.channels.get_channel_members(channel_id)
        existing_member_user_ids = [member.get('user_id') for member in existing_members]
        existing_user_ids = any(uid in user_ids for uid in existing_member_user_ids)
        if existing_user_ids:
            # If the channel already has members, we should not add them again
            # This is a safeguard against creating duplicate entries in an archived channel
            print(f"[DEBUG] Existing members in channel {channel_id}: {existing_member_user_ids}, this shouldn't happen! archived channels should be empty")
            return
        # make sure not adding randos
        current_members_ids = [m['user_id'] for m in self.driver.channels.get_channel_members(message.channel_id)]
        if not (user_ids[0] in current_members_ids and user_ids[1] in current_members_ids and
                user_ids[2] in current_members_ids and user_ids[3] in current_members_ids):
            self.driver.reply_to(message, f"Could not find users")
            return

        # Add users to channel
        for uid in user_ids:
            logger.debug(f"Adding user {uid} to channel {channel_id}")
            self.driver.channels.add_channel_member(channel_id, {"user_id": uid})
        self.driver.reply_to(message, f"Created channel '{display_name}' and added users: {user1}, {user2}, {user3}")
        logger.info(f"Created channel '{display_name}' and added users: {user1}, {user2}, {user3}")

    @listen_to('^!add_offering (.*)$', no_direct=True,allowed_users_glob=["mod_*"], human_description="!add_offering name type os oday_or_nday creator price\n\tAdd a new malware offering.")
    def add_offering_cmd(self, message: Message, *args):
        args = message.text.strip().split()
        logger.debug(f"add_offering_cmd called with args: {args}")
        if len(args) != 7:
            self.driver.reply_to(message, "Usage: !add_offering name type os oday_or_nday creator price")
            logger.warning("add_offering: Incorrect number of arguments")
            return
        _, name, mtype, osys, oday_nday, creator, price = args
        mtype_lc = mtype.lower()
        osys_lc = osys.lower()
        oday_nday_lc = oday_nday.lower()
        logger.debug(f"Normalized values: type={mtype_lc}, os={osys_lc}, oday_nday={oday_nday_lc}")
        if mtype_lc not in [t.lower() for t in MALWARE_TYPES]:
            self.driver.reply_to(message, f"Invalid malware type. Allowed: {', '.join(MALWARE_TYPES)}")
            logger.warning(f"add_offering: Invalid malware type '{mtype}'")
            return
        if osys_lc not in [o.lower() for o in OS_TYPES]:
            self.driver.reply_to(message, f"Invalid OS. Allowed: {', '.join(OS_TYPES)}")
            logger.warning(f"add_offering: Invalid OS '{osys}'")
            return
        if oday_nday_lc not in [d.lower() for d in ODAYS]:
            self.driver.reply_to(message, "oday_or_nday must be '0day' or 'nday'.")
            logger.warning(f"add_offering: Invalid oday_or_nday '{oday_nday}'")
            return
        team_name = self.driver.options.get('team', 'malwarecentral')
        team = self.driver.teams.get_team_by_name(team_name)
        team_id = team.get('id') if isinstance(team, dict) else team.json().get('id')
        user = self.driver.users.get_user_by_username(creator)
        if not user or (user.get('id') if isinstance(user, dict) else user.json().get('id')) is None:
            self.driver.reply_to(message, f"Creator '{creator}' is not a valid user in the team.")
            logger.warning(f"add_offering: Creator '{creator}' is not a valid user in the team.")
            return
        try:
            price_val = float(price)
            if price_val < 0:
                raise ValueError
        except ValueError:
            self.driver.reply_to(message, "Price must be a positive number.")
            logger.warning(f"add_offering: Invalid price '{price}'")
            return
        offering = {
            'name': name,
            'type': mtype_lc,
            'os': osys_lc,
            'oday_or_nday': oday_nday_lc,
            'creator': creator,
            'price': price_val
        }
        logger.info(f"Adding offering: {offering}")
        oid = db.add_offering(offering)
        self.driver.reply_to(message, f"Offering added with ID {oid}.")
        logger.info(f"Offering added with ID {oid}")

    @listen_to('^!get_offerings (.*)$', no_direct=True, human_description="!get_offerings\n\tList all malware offerings.")
    def get_offerings_cmd(self, message: Message, *args):
        logger.debug(f"get_offerings_cmd called with message: {message.text}")
        offerings = db.get_offerings()
        logger.debug(f"Offerings retrieved: {offerings}")
        if not offerings:
            self.driver.reply_to(message, "No offerings available.")
            logger.info("get_offerings_cmd: No offerings available.")
            return
        msg = "Malware Offerings:\n" + "\n".join([
            f"ID: {o['id']}, Name: {o['name']}, Type: {o['type']}, OS: {o['os']}, Oday/Nday: {o['oday_or_nday']}, Creator: {o['creator']}, Price: {o['price']}"
            for o in offerings
        ])
        self.driver.reply_to(message, msg)
        logger.info("get_offerings_cmd: Sent offerings list.")

    #TODO update these users to be other admins we expect to be listed within the team
    @listen_to('^!record_sale (.*)$', no_direct=True, allowed_users_glob=["mod_*"],human_description="!record_sale buyer price offering_id\n\tRecord a sale of malware.",allowed_users=["badguy","otherbadguy","some guys","user1"])
    def record_sale_cmd(self, message: Message, *args):
        logger.debug(f"record_sale_cmd called with message: {message.text}")
        args = message.text.strip().split()
        if len(args) != 4:
            self.driver.reply_to(message, "Usage: !record_sale buyer price offering_id")
            logger.warning("record_sale_cmd: Incorrect number of arguments")
            return
        _, buyer, price, offering_id = args
        # Validate buyer is a user in the team
        team_name = self.driver.options.get('team', 'malwarecentral')
        team = self.driver.teams.get_team_by_name(team_name)
        team_id = team.get('id') if isinstance(team, dict) else team.json().get('id')
        user = self.driver.users.get_user_by_username(buyer)
        if not user or (user.get('id') if isinstance(user, dict) else user.json().get('id')) is None:
            self.driver.reply_to(message, f"Buyer '{buyer}' is not a valid user in the team.")
            logger.warning(f"record_sale_cmd: Buyer '{buyer}' is not a valid user in the team.")
            return
        # Seller is the creator of the offering
        offerings = db.get_offerings()
        offering = next((o for o in offerings if str(o['id']) == offering_id), None)
        if not offering:
            self.driver.reply_to(message, f"Offering ID {offering_id} not found.")
            logger.warning(f"record_sale_cmd: Offering ID {offering_id} not found.")
            return
        seller = offering['creator']
        sale = {
            'buyer': buyer,
            'seller': seller,
            'price': price,
            'offering_id': offering_id
        }
        logger.info(f"Recording sale: {sale}")
        db.record_sale(sale)
        self.driver.reply_to(message, f"Sale recorded for offering ID {offering_id}.")
        logger.info(f"Sale recorded for offering ID {offering_id}")
