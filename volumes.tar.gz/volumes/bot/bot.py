#!/usr/bin/env python
import sys
from loguru import logger

# Set log level based on -v argument
if "-v" in sys.argv:
    logger.remove()
    logger.add(sys.stderr, level="DEBUG")
else:
    logger.remove()
    logger.add(sys.stderr, level="INFO")

import mmpy_bot_monkeypatch  # Ensure monkeypatch is applied before any plugin imports
from mmpy_bot import Bot, Settings
from mmpy_bot.plugins import HelpPlugin
from plugin_sales import SalesPlugin
from plugin_onboarding import OnboardingPlugin
from plugin_admin import AdminPlugin
from plugin_managechannel import ManageChannelPlugin
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

bot = Bot(
    settings=Settings(
        MATTERMOST_URL = os.environ.get("MATTERMOST_URL", "http://127.0.0.1"),
        MATTERMOST_PORT = int(os.environ.get("MATTERMOST_PORT", 8065)),
        BOT_TOKEN = os.environ.get("BOT_TOKEN"),
        BOT_TEAM = os.environ.get("BOT_TEAM", "test_team"),
        SSL_VERIFY = os.environ.get("SSL_VERIFY", "False") == "True",
        RESPOND_CHANNEL_HELP=True,
    ),
    plugins=[SalesPlugin(), HelpPlugin(), OnboardingPlugin(),ManageChannelPlugin(),AdminPlugin()],
)
bot.run()
