from mmpy_bot_monkeypatch import *  # Ensure monkeypatch is applied before anything else
from mmpy_bot import Plugin, Message, listen_to
from malware_database import db
from loguru import logger


def get_pinned(driver, message: Message, *args):
    logger.debug(f"handle_get_pinned called with message: {message.text}")
    team_name = driver.options.get('team', 'malwarecentral')
    print(f"[DEBUG] Looking up team: {team_name}")
    # Get team info
    team = driver.teams.get_team_by_name(team_name)
    channel_id = message.channel_id
    posts = driver.channels.get_pinned_posts(channel_id)
    logger.info(f"found pinned posts {posts}")
    order= posts["order"]
    all_pinned ={}
    for post in order:
        all_pinned[post] = posts["posts"][post]["message"]
    logger.info(f"respons is {all_pinned}")
    return all_pinned


class ManageChannelPlugin(Plugin):
    """
    A plugin to handle Managing Channel Posts
    """

        
    @listen_to('^!delete nonpinned', no_direct=True,human_description="!delete nonpinned\n\tget rid of any posts that aren't pinned")
    def handle_delete_nonpinned(self : Plugin, message: Message, *args):
        all_pinned = get_pinned(self.driver, message)
        channel_id = message.channel_id
        posts = self.driver.posts.get_posts_for_channel(channel_id)["order"]
        logger.info(f"got {len(posts)} posts for this channel")
        logger.info(posts)
        logger.info(all_pinned)
        #loop through every post and delete the ones that aren't pinned
        count = 0 
        while (len(posts) > len(all_pinned.items())):
            for post in posts:
                if post not in all_pinned:
                    self.driver.posts.delete_post(post)
                    count += 1
            posts = self.driver.posts.get_posts_for_channel(channel_id)["order"]
            logger.info(f"got {len(posts)} posts for this channel")

        