from mmpy_bot import Plugin
from mmpy_bot.scheduler import schedule
from loguru import logger
from malware_database import db
from mmpy_bot.function import listen_to

ANNOUNCEMENT_CHANNEL = "public"
ANNOUNCEMENT_RULES = """
Welcome to the Malware Marketplace! Please read the rules and stay safe.
1. Do not discuss illegal activities
2. Do not wreak havoc
3. Do not make $$$$
4. Don't even consider HACK(ing) THE PLANET
5. Always buck authority

Current info and updates will appear here.
"""
ANNOUNCEMENT_MIDDLE = "No current announcements"

class OnboardingPlugin(Plugin):
    """Plugin to send onboarding/welcome/rules announcements."""

    def on_start(self):
        self.announcement_middle = ANNOUNCEMENT_MIDDLE
        logger.info(f"PluginOnboarding: Sending initial announcement to {ANNOUNCEMENT_CHANNEL}")
        self.send_announcement()
        schedule.every(1).hours.do(self.send_announcement)

    @listen_to("^!update_announcement (.+)$", allowed_users_glob=["mod_*"])
    def update_announcement_cmd(self, message, new_middle):
        logger.info(f"PluginOnboarding: Announcement middle updated by {message.sender_name}")
        self.announcement_middle = new_middle
        self.send_announcement()
        self.driver.reply_to(message, "Announcement updated and sent.")

    def send_announcement(self):
        # Get team name from driver options
        team_name = self.settings.BOT_TEAM
        # Get channel info by name and team name (works for public/private)
        channel = self.driver.channels.get_channel_by_name_for_team_name(team_name, ANNOUNCEMENT_CHANNEL)
        channel_id = channel.get('id') if isinstance(channel, dict) else channel.json().get('id')
        # Get current offerings
        offerings = db.get_offerings()
        offerings_text = "Current Offerings:\n" + "\n".join([
            f"ID: {o['id']}, Name: {o['name']}, Type: {o['type']}, OS: {o['os']}, Price: {o['price']}" for o in offerings
        ]) if offerings else "No current offerings."
        announcement = f"{ANNOUNCEMENT_RULES}\n\n{self.announcement_middle}\n\n{offerings_text}"
        logger.debug(f"PluginOnboarding: Sending announcement to channel_id={channel_id}")
        self.driver.create_post(channel_id=channel_id, message=announcement)
